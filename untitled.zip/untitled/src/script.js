const SUPABASE_URL = "https://apbhfspyxhqjgbcotsuq.supabase.co";

const SUPABASE_KEY = "sb_publishable_qRnxXRfstzreVB8kvBBFxQ_uSxc8qM6";

const supabaseClient = supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);

document.getElementById("notifyButton").addEventListener("click", async function () {

  const location = document.getElementById("location").value;
  const message = document.getElementById("message").value.trim();
  const result = document.getElementById("result");
  const button = document.getElementById("notifyButton");

  if (!location || !message) {
    result.textContent = "Please select a location and write a message.";
    result.style.color = "red";
    return;
  }

  button.disabled = true;
  result.textContent = "Sending...";
  result.style.color = "#666";

  const { error } = await supabaseClient
    .from("found_items")
    .insert([
      {
        tag_id: "US-001",
        location: location,
        message: message
      }
    ]);

  button.disabled = false;

  if (error) {
    console.error(error);
    result.textContent = "Something went wrong.";
    result.style.color = "red";
  } else {
    result.textContent = "Report sent successfully! 🎉";
    result.style.color = "green";
  }
});
